Custom Weather Client Tool

Following are key point to run the application :-

a) The Application is develop in Asp .Net and runs on URl -  https://{localhost:Id}/Home/Weather  e.g https://localhost:44319/Home/Weather.
b) Kindly check the part of the in.json file before running the application.i.e. present in Views -> shared -> in.json;
		i) The path is used in HomeController.cs Line 56 
c)Run the application through IIS Express
