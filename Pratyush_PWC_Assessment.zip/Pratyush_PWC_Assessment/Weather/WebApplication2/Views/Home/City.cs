﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Views.Home
{
    public class City
    {
     public string city {get;set;}
     public string lat { get; set; }
     public string lng {get;set;}
     public string country  {get;set;}
     public string iso2 {get;set;}
     public string admin_name { get; set; }
     public string capital  {get;set;}
     public string population { get; set; }
     public string population_proper { get; set; }
    }
}
