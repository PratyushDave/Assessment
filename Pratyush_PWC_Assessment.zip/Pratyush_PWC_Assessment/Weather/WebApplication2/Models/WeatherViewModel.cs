﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class WeatherViewModel
    {
        public class ResultViewModel
        {
            public float Longitude { get; set; }
            public float Latitude { get; set; }
            public double Generationtime_ms { get; set; }
            public string Timezone { get; set; }
            public string Timezone_abbreviation { get; set; }
            public float Elevation { get; set; }
            public double Temperature { get; set; }
            public int Utc_offset_seconds { get; set; }
            public double Windspeed { get; set; }
            public double Winddirection { get; set; }
            public double Weathercode { get; set; }
            public DateTime Time { get; set; }

        }

        public class Current_Weather
        {
            public double Temperature { get; set; }
            public double Windspeed { get; set; }
            public double Winddirection { get; set; }
            public double Weathercode { get; set; }
            public DateTime Time { get; set; }
        }


        public class RootObject
        {
            public float Longitude { get; set; }
            public float Latitude { get; set; }
            public double Generationtime_ms { get; set; }
            public int Utc_offset_seconds { get; set; }
            public string Timezone { get; set; }
            public string Timezone_abbreviation { get; set; }
            public float Elevation { get; set; }
            public Current_Weather Current_Weather { get; set; }

        }
    }
}
