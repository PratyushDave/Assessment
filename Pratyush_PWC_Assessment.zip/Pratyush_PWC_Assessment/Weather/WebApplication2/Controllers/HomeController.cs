﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using WebApplication2.Models;
using System.Net;
using static WebApplication2.Models.WeatherViewModel;
using Newtonsoft.Json;
using System.IO;
using System.Collections.Generic;
using WebApplication2.Views.Home;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;

namespace WebApplication2.Controllers
{
  
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public ActionResult Weather()
        {

            return View();
        }
        [HttpPost]
        public string WeatherDetail(IFormCollection form)
        {
            string enteredCity = form["Name"];
            string lat = "18.9667";
            string lon = "72.8333";
            List<City> items = new List<City>();
            using (StreamReader r = new StreamReader("C:/Users/Pratyush/source/repos/WebApplication2/WebApplication2/Views/Shared/in.json"))
            {
                string json = r.ReadToEnd();
                items = JsonConvert.DeserializeObject<List<City>>(json);

            }
            List<City> result = items.FindAll(x => x.city == enteredCity).ToList();
            foreach (var i in result)
            {
                lat = i.lat;
                lon = i.lng;
            }
            var longitudeValue = Convert.ToDouble(lon);
            var latitudeValue = Convert.ToDouble(lat);
            string url = string.Format("http://api.open-meteo.com/v1/forecast?latitude={0}&longitude={1}&current_weather=true", latitudeValue, longitudeValue);
            using (WebClient client = new WebClient())
            {
                string json = client.DownloadString(url);
                RootObject weatherInfo = JsonConvert.DeserializeObject<RootObject>(json);
                ResultViewModel rslt = new ResultViewModel();
                rslt.Latitude = (float)weatherInfo.Latitude;
                rslt.Longitude = (float)weatherInfo.Longitude;
                rslt.Generationtime_ms = weatherInfo.Generationtime_ms;
                rslt.Utc_offset_seconds = weatherInfo.Utc_offset_seconds;
                rslt.Timezone = weatherInfo.Timezone;
                rslt.Timezone_abbreviation = weatherInfo.Timezone_abbreviation;
                rslt.Elevation = weatherInfo.Elevation;
                rslt.Temperature = (float)weatherInfo.Current_Weather.Temperature;
                rslt.Windspeed = weatherInfo.Current_Weather.Windspeed;
                rslt.Winddirection = weatherInfo.Current_Weather.Winddirection;
                rslt.Weathercode = weatherInfo.Current_Weather.Weathercode;
                rslt.Time = weatherInfo.Current_Weather.Time;
                var jsonstring = JsonConvert.SerializeObject(rslt);
                return jsonstring;
            }
        }

    }
}
