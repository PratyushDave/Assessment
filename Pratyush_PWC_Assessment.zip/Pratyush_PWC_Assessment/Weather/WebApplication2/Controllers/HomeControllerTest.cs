﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Primitives;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using Xunit.Extensions.Ordering;
using static WebApplication2.Models.WeatherViewModel;

namespace WebApplication2.Controllers
{
    public class HomeControllerTest : Controller
    {
        private HomeController _controller;
        [Fact]
        public async Task TestWeatherDetail()
        {
            IActionResult res;
            var httpContext = new DefaultHttpContext();
            var request = httpContext.Request;
            var formDictionary = new Dictionary<string, StringValues>();
            formDictionary.Add("Name", "Mumbai");
            request.Form = new FormCollection(formDictionary);
            var result = _controller.WeatherDetail(request.Form);
            List<string> lst = new List<string>();
            lst.Add(result);
            if(lst.Count >0)
            {
                res = Ok();
                var resultStatus= res as OkObjectResult;
                Assert.NotNull(resultStatus);
                Assert.NotNull(resultStatus.Value);
                Assert.True(resultStatus.StatusCode == 200);
            }
        }

    }
}
